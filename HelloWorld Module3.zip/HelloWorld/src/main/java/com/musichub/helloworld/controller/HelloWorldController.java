package com.musichub.helloworld.controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
 
@Controller
public class HelloWorldController {	
	@RequestMapping("/login")
	public ModelAndView showMessage(
			@RequestParam(value = "name", required = false, defaultValue = "World") String name) {
		System.out.println("in controller"); 
		ModelAndView mv = new ModelAndView("login");		
		mv.addObject("name", name);
		return mv;
	}
	
	@RequestMapping("/Register")
	public ModelAndView registers(
		@RequestParam(value = "name", required = false, defaultValue = "World") String name) {
		System.out.println("in controller");
 		ModelAndView mv = new ModelAndView("Register");
		mv.addObject("name", name);
		return mv;
	}
	
	@RequestMapping("/picdetails")
	public ModelAndView thumbnails(
			@RequestParam(value = "id", required = false, defaultValue = "World") String id,
			@RequestParam(value = "name", required = false, defaultValue = "World") String name,
			@RequestParam(value = "description", required = false, defaultValue = "World") String description,
			@RequestParam(value = "price", required = false, defaultValue = "World") String price
			) {
		System.out.println("in controller");
 
		ModelAndView mv = new ModelAndView("picdetails");
		mv.addObject("id",id);
		mv.addObject("name", name);
		mv.addObject("description",description);
		mv.addObject("price",price);
		return mv;
			}
	
	@RequestMapping("/prodetails")
	public ModelAndView allproducts(
	@RequestParam(value = "names", required = false, defaultValue = "World") String names) {
	System.out.println("in controller");
	ModelAndView mv = new ModelAndView("prodetails");		
		mv.addObject(names);	
		return mv;
	}		
}