package com.musichub.helloworld.controller;

import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.google.gson.Gson;
import com.musichub.helloworld.DAO.productdaoimp;
import com.musichub.helloworld.DAO.*;

@Controller
public class HelloWorldController {	
	productdaoimp p = new productdaoimp();
	List<product> prod;
	@RequestMapping("/login")
	public ModelAndView showMessage(
			@RequestParam(value = "name", required = false, defaultValue = "World") String name) {
		System.out.println("in controller"); 
		ModelAndView mv = new ModelAndView("login");		
		mv.addObject("name", name);
		return mv;
	}	
	@RequestMapping("/Register")
	public ModelAndView registers(
		@RequestParam(value = "name", required = false, defaultValue = "World") String name) {
		System.out.println("in controller");
 		ModelAndView mv = new ModelAndView("Register");
		mv.addObject("name", name);
		return mv;
	}
		
	String str;
	@RequestMapping("/prodetails")
	public ModelAndView allproducts(
	@RequestParam(value = "name", required = false, defaultValue = "World") String name) {
		str=name;
	System.out.println("in controller");
	ModelAndView mv = new ModelAndView("prodetails");		
		//mv.addObject(names);	
		return mv;
	}	
	
	@RequestMapping("productdetailInfo")
	public @ResponseBody String productdetails()
	{
		
		/*if(str.equals("ARRahaman")||str.equals("GVPrakash")||str.equals("Chithra"))
		{
			prod = p.getProduct(str);
		}*/
		
		if(str.equals("ARRahaman"))
		{
			  prod = p.getProduct(str);
		}
		if(str.equals("GVPrakash"))
		{
			  prod = p.getProduct(str);
		}
	   if(str.equals("Chithra"))
		{
			 prod = p.getProduct(str);
		}
		if(str.equals("all"))
		{
		
	     prod = p.getAllProducts();
		}
	    Gson gson = new Gson();
	    String json = gson.toJson(prod);
	    return json;
	   	}
	
	@RequestMapping("/moreinfo")
	public ModelAndView moreinformation() {
	ModelAndView mv = new ModelAndView("moreinfo");		
		return mv;
	}
	
	}
