package com.musichub.helloworld.DAO;
import java.util.List;

public interface productdao {
   public List<product> getAllProducts();
   public List<product> getProduct(String name);
      
}