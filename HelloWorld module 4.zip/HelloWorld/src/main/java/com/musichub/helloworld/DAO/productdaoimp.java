package com.musichub.helloworld.DAO;
import java.util.ArrayList;
import java.util.List;

public class productdaoimp implements productdao {
	
	//list is working as a database
   List<product> prod;
   
   public  productdaoimp(){
	   /*prod = new ArrayList<product>();
	   product p1 = new product("1","AR Rahaman","melody","1000");
	   product p2 = new product("2","chitra","karnatic","2000");
	   product p3 = new product("3","GVP","RAP","12000");
      prod.add(p1);
      prod.add(p2);	
      prod.add(p3);*/
      
   }
   
   @Override
   public List<product> getAllProducts() {
	   prod = new ArrayList<product>();
	   product p1 = new product("1","AR Rahaman","melody","1000");
	   product p2 = new product("2","chitra","karnatic","2000");
	   product p3 = new product("3","GVP","RAP","12000");
      prod.add(p1);
      prod.add(p2);	
      prod.add(p3);
      return prod;
   }
   public List<product> getProduct(String name)
   {
	   product p1 = null;
	   prod = new ArrayList<product>();
	   if(name.equals("ARRahaman")){
	   p1 = new product("1","AR Rahaman","melody","1000");	   
	   }
	   if(name.equals("GVPrakash"))		   
	   {
	   p1 = new product("2","chitra","karnatic","2000");	   	 
	   }
	   if(name.equals("Chithra")){
	   p1= new product("3","GVP","RAP","12000");         
   }
	   prod.add(p1);
	   return prod;
   }
}
  

